
//Write a program to demonstrate constructor, encapsulation and Inheritance .

package javaprograms.com;

 class Demo {
	
	int num=10;
	
	private String value;//encapsulation
	
	Demo(int i) {
		
		this.num=i;      //constructor
	}
	public void setValue(String str) {
		value=str;
	}
	public String getValue() {
		return value;
	}

}

 class InheritanceDemo extends Demo{  //inheritance

	 InheritanceDemo(int i) {
		super(i);
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String args[]) {
		
		Demo demo=new Demo(50);
		
		System.out.println(demo.num);
		
		demo.setValue("Maveric Systems");
		
		System.out.println(demo.getValue());
		
		
	}
	
}
 
/* output
 
 50  //changing number from 10 to 50 through constructor and inheritance
 Maveric Systems // encapsulation of private data
*/