package javaprograms.com;
import java.io.File; 
import java.io.FileNotFoundException;  
import java.util.Scanner;

public class ReadFiles {
	
  public static void main(String[] args) {
	  
    try {
    	
      File myObj = new File("C:\\Users\\Public\\text.txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
         if(myReader.nextLine() != null) {
        	 System.out.println(data);
         }
       
      }
      myReader.close();
    } 
      catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}

/*text.txt file like this 

Preethi
Uma
Usha
Shree


-- output is ----

Preethi
Usha*/
