package javaprograms.com;

public interface MethodOverloadingInterface {
	
	public void bike();
	public void Move(int speed);

}
