package javaprograms.com;

public class MethodOverloadingDemo implements MethodOverloadingInterface{

	String bikeName="";
	
	@Override
	public void bike() {
		// TODO Auto-generated method stub
		bikeName="Royal EnField";
		System.out.println("From Child Class Implementation "+bikeName);
	}
	@Override
	public void Move(int speed) {
		// TODO Auto-generated method stub
		System.out.println("method with data type int "+speed);
	}
	public void Move(double speed) {
		
		System.out.println("method with data type double "+speed);	
	}
	public void bike(String Name) {
		// TODO Auto-generated method stub
		System.out.println("From Child Class Implementation "+Name);
	}

	public static void main(String[] args) {
		
		MethodOverloadingDemo obj=new MethodOverloadingDemo();
		
		obj.bike();
		
		obj.bike("Pulser");
		
		obj.Move(100);
		
		obj.Move(110.00);
		
	}

}

/*Output

From Child Class Implementation Royal EnField
From Child Class Implementation Pulser
method with data type int 100
method with data type double 110.0*/
