package javaprograms.com;

public class RemoveString {
	
	public static void main(String args[]) {
		
		String str="REST ASSURED";
		
		System.out.println("Given String is "+str);
		
		String s=str.replace("ST", "");
		
		System.out.println("Given String is After Removing St is "+s);
		
		String s1="Preethi";
		
		String s2="preethi";
		
		if(s1==s2) {
			
			System.out.println("Strings are equal");
		}
		else if(s1.equalsIgnoreCase(s2)) {
			
			System.out.println("Strings are equal");
		}
		else
			System.out.println("Strings are not equal");
	}

}


/*output

Given String is REST ASSURED
Given String is After Removing St is RE ASSURED
Strings are equal*/