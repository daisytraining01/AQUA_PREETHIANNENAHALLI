package javaprograms.com;

	class FibanocciExamp 
	{ 
		 public static void main(String[] args) {

		        int count = 6, num1 = 0, num2 = 1;
		        
		        System.out.println("Fibonacci Series of "+count+" numbers:");

		        int i=1;
		        
		        while(i<=count)
		        {
		            System.out.print(num1+" ");
		            
		            int sum = num1 + num2;
		            num1 = num2;
		            num2 = sum;
		            i++;
		        }
		    }
	} 

/*	 output
	 
	 Fibonacci Series of 6 numbers:
		 0 1 1 2 3 5 */