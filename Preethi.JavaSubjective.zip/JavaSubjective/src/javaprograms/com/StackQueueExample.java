package javaprograms.com;

import java.util.*; 

class StackQueueExample  
{

	 int arr[];
	 int top;
	 int capacity;
	
	 int front;		
	 int rear;
	 int count;

	StackQueueExample(int size)
	{
		arr = new int[size];
		capacity = size;
		top = -1;
		
	}
	
	StackQueueExample(int size,int front,int rear)
	{
		arr = new int[size];
		capacity = size;
		this.front = 0;
		this.rear = -1;
		count = 0;
		
	}

	public void push(int x)
	{
		if (top == capacity - 1)
		{
			System.out.println("Stack-OverFlow....");
			System.exit(1);
		}

		System.out.println("Stack-Inserting.... " + x);
		arr[++top] = x;
	}

	public int pop()
	{
		if (top == -1)
		{
			System.out.println("Stack-UnderFlow....");
			System.exit(1);
		}

		System.out.println("Stack-Removing...." + getStackpeek());
		return arr[top--];
	}

	public int getStackpeek()
	{
		if (!(top == -1))
			return arr[top];
		else
			System.exit(1);

		return -1;
	}

	public int getStackSize()
	{
		return top + 1;
	}
	
	public void dequeue()
	{
		if (isQueueEmpty())
		{
			System.out.println("Queue-UnderFlow....");
			System.exit(1);
		}

		System.out.println("Queue - Removing...." + arr[front]);

		front = (front + 1) % capacity;
		count--;
	}
	public void enqueue(int item)
	{
		if (isQueueFull())
		{
			System.out.println("Queue -OverFlow....");
			System.exit(1);
		}

		System.out.println("Queue-Inserting...." + item);

		rear = (rear + 1) % capacity;
		arr[rear] = item;
		count++;
	}

	public int getQueuepeek()
	{
		if (isQueueEmpty()) 
		{
			System.out.println("Queue-UnderFlow...");
			System.exit(1);
		}
		return arr[front];
	}
	public int getQueueSize()
	{
		return count;
	}
	public Boolean isQueueEmpty()
	{
		return (getQueueSize() == 0);
	}
	public Boolean isQueueFull()
	{
		return (getQueueSize() == capacity);
	}
	
	public static void main (String[] args)
	{
		StackQueueExample stack = new StackQueueExample(3);

		stack.push(1);		
		stack.push(2);		

		stack.pop();		
		stack.pop();		

		stack.push(3);		

		System.out.println("Top element is: " + stack.getStackpeek());
		System.out.println("Stack size is " + stack.getStackSize());

		stack.pop();	

		
		if (stack.top == -1)
			System.out.println("Stack Is Empty");
		else
			System.out.println("Stack Is Not Empty");
		
		
		StackQueueExample q = new StackQueueExample(5,0,-1);

		q.enqueue(1);
		q.enqueue(2);
		q.enqueue(3);
		
		System.out.println("Front element is: " + q.getQueuepeek());
		q.dequeue();
		System.out.println("Front element is: " + q.getQueuepeek());

		System.out.println("Queue size is " + q.getQueueSize());

		q.dequeue();
		q.dequeue();
		
		if (q.isQueueEmpty())
			System.out.println("Queue Is Empty");
		else
			System.out.println("Queue Is Not Empty");
	} 
}



// Stack (Last In First Out) Output 


/*Stack-Inserting.... 1
Stack-Inserting.... 2
Stack-Removing....2
Stack-Removing....1
Stack-Inserting.... 3
Top element is: 3
Stack size is 1
Stack-Removing....3
Stack Is Empty*/


//Queue (First In First Out) Output


/*Queue-Inserting....1
Queue-Inserting....2
Queue-Inserting....3
Front element is: 1
Queue - Removing....1
Front element is: 2
Queue size is 2
Queue - Removing....2
Queue - Removing....3
Queue Is Empty*/

