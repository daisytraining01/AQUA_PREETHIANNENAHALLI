package javaprograms.com;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class RemoveDuplicates {
	
	public static void main(String[] args) {
		
		Map<String,String> map=new HashMap<String,String>(); 
		
		map.put("Key 1", "TestVal1");
		map.put("Key 2", "TestVal2");
		map.put("Key 3", "TestVal1");
		map.put("Key 4", "TestVal2");
		map.put("Key 5", "TestVal2");
		map.put("Key 6", "TestVal3");	
		
		
		for(Entry entry:map.entrySet()) {
	    	   
	    	  
	    	   System.out.println("Key is "+entry.getKey()+" Duplicate Value is "+entry.getValue());
	    	   
	    	   
	       }
		
		Set<String> keys = map.keySet(); // The set of keys in the map.

		Map<String,String> map1=new HashMap<String,String>();
		
		Iterator<String> itr = keys.iterator();

		while (itr.hasNext()) {
		    String key = itr.next();
		    String value = map.get(key);
		    map1.put(value, key);
		}
		
       for(Entry entry:map1.entrySet()) {
    	   System.out.println("Key is "+entry.getKey()+" Value is "+entry.getValue());
       }
		
	}

}


/*Output 


Key is Key 1 Duplicate Value is TestVal1
Key is Key 2 Duplicate Value is TestVal2
Key is Key 3 Duplicate Value is TestVal1
Key is Key 4 Duplicate Value is TestVal2
Key is Key 5 Duplicate Value is TestVal2
Key is Key 6 Duplicate Value is TestVal3
Key is TestVal1 Value is Key 3
Key is TestVal2 Value is Key 5
Key is TestVal3 Value is Key 6*/

